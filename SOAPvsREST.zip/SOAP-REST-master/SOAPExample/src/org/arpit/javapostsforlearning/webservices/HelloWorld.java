package org.arpit.javapostsforlearning.webservices;
 
public class HelloWorld {
 
 public String sayHelloWorld(String name)
 {
 return "Hello world from "+ name;
 }
}