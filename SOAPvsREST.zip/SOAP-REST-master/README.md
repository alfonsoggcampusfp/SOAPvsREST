Un documento de Word que explique muy brevemente la diferencia entre SOAP y REST.
Dos proyectos en Eclipse, uno que consuma un SOAP y otro un REST
